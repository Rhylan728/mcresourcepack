# Enter file: find_unused_chars.py

import json

# Path to the default Minecraft font JSON
JSON_PATH = r"C:\Users\shawn\Desktop\awdawd\PremiumSetupTexturepack\assets\minecraft\font\default.json"

# Private Use Area range in the BMP where Minecraft doesn’t define glyphs
PUA_START = 0xE000
PUA_END   = 0xF8FF

def load_used_codepoints(path):
    with open(path, encoding='utf-8') as f:
        data = json.load(f)
    # Minecraft JSON uses a "providers" list
    entries = data.get("providers", data if isinstance(data, list) else [])
    used = set()
    for entry in entries:
        for ch in entry.get("chars", []):
            used.add(ord(ch))
    return used

def find_unused_in_pua(used, start, end):
    return [cp for cp in range(start, end + 1) if cp not in used]

def main():
    used = load_used_codepoints(JSON_PATH)
    unused = find_unused_in_pua(used, PUA_START, PUA_END)
    print(f"Found {len(unused)} unused codepoints in U+{PUA_START:04X}–U+{PUA_END:04X}.")

    # Write them all to unused.txt in "CODE | CHARACTER" format
    output_path = "unused.txt"
    with open(output_path, 'w', encoding='utf-8') as out:
        for cp in unused:
            # hex code without the "U+" prefix, e.g. "E000"
            code_hex = f"{cp:04X}"
            char = chr(cp)
            out.write(f"{code_hex} | {char}\n")

    print(f"All unused codepoints exported to {output_path}")

if __name__ == "__main__":
    main()
